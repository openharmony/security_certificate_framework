---
name: cert-chain-issuer
description: |
  Create and manage certificate chains using OpenSSL for development and testing.
  Use this skill when the user asks to create certificates, set up a CA, issue
  server/client certificates, generate certificate chains, or work with PKI
  infrastructure. Triggers on: "create certificate", "generate cert", "set up CA",
  "issue certificate", "certificate chain", "self-signed certificate", "TLS cert",
  "SSL certificate", "root CA", "intermediate CA", "code signing cert".
---

# Certificate Chain Issuer

A workflow for creating certificate chains with OpenSSL, designed for development and testing environments.

## Overview

This skill helps you:
1. Create a Root CA
2. Create Intermediate CAs (configurable depth)
3. Issue end-entity certificates (server, client, code-signing)
4. Generate complete certificate chains
5. Verify certificate chains

## Quick Start

Ask the user for:
- **Chain depth**: How many levels? (2 = root + end, 3+ = root + intermediates + end)
- **Certificate type**: server, client, or code-signing
- **Subject details**: CN, O, OU, C, etc.
- **Validity period**: Days until expiration
- **Key parameters**: Algorithm (RSA/ECDSA), key size
- **Advanced extensions** (optional): Key Usage, AIA, CRLDP

## Directory Structure

Organize certificates in a standard hierarchy:
```
certs/
├── root/
│   ├── root-ca.key
│   ├── root-ca.crt
│   └── root-ca.srl
├── intermediate-N/          # One directory per intermediate
│   ├── intermediate.key
│   ├── intermediate.crt
│   └── intermediate.srl
└── end-entity/
    ├── server.key
    ├── server.crt
    └── fullchain.crt       # Complete chain file
```

## Workflow

### Step 1: Create Root CA

```bash
# Generate Root CA private key
openssl genrsa -out root/root-ca.key 4096

# Create Root CA certificate (self-signed, 10 years validity)
openssl req -x509 -new -nodes -key root/root-ca.key \
    -sha256 -days 3650 \
    -subj "/C=US/ST=State/L=City/O=MyOrg/OU=Root CA/CN=MyOrg Root CA" \
    -out root/root-ca.crt

# Create serial file
echo "01" > root/root-ca.srl
```

### Step 2: Create Intermediate CA(s)

For each intermediate CA in the chain:

```bash
# Generate intermediate CA private key
openssl genrsa -out intermediate-1/intermediate.key 4096

# Create CSR for intermediate CA
openssl req -new -key intermediate-1/intermediate.key \
    -subj "/C=US/ST=State/L=City/O=MyOrg/OU=Intermediate CA/CN=MyOrg Intermediate CA" \
    -out intermediate-1/intermediate.csr

# Sign with parent CA (root for first intermediate, previous intermediate for others)
openssl x509 -req -in intermediate-1/intermediate.csr \
    -CA root/root-ca.crt -CAkey root/root-ca.key \
    -CAcreateserial -out intermediate-1/intermediate.crt \
    -days 1825 -sha256 \
    -extfile <(echo -e "basicConstraints=critical,CA:TRUE,pathlen:1\nkeyUsage=critical,keyCertSign,cRLSign")

# Create serial file for this intermediate
echo "01" > intermediate-1/intermediate.srl
```

### Step 3: Issue End-Entity Certificate

#### Server Certificate (for TLS/HTTPS)

```bash
# Generate server key
openssl genrsa -out end-entity/server.key 2048

# Create CSR
openssl req -new -key end-entity/server.key \
    -subj "/C=US/ST=State/L=City/O=MyOrg/OU=IT/CN=server.example.com" \
    -out end-entity/server.csr

# Sign with the last CA in chain (intermediate or root if no intermediates)
openssl x509 -req -in end-entity/server.csr \
    -CA intermediate-1/intermediate.crt -CAkey intermediate-1/intermediate.key \
    -CAcreateserial -out end-entity/server.crt \
    -days 365 -sha256 \
    -extfile <(echo -e "basicConstraints=CA:FALSE\nkeyUsage=critical,digitalSignature,keyEncipherment\nextendedKeyUsage=serverAuth\nsubjectAltName=DNS:server.example.com,DNS:localhost,IP:127.0.0.1")
```

#### Client Certificate (for mTLS)

```bash
# Generate client key
openssl genrsa -out end-entity/client.key 2048

# Create CSR
openssl req -new -key end-entity/client.key \
    -subj "/C=US/ST=State/L=City/O=MyOrg/OU=Users/CN=john.doe" \
    -out end-entity/client.csr

# Sign with the last CA in chain
openssl x509 -req -in end-entity/client.csr \
    -CA intermediate-1/intermediate.crt -CAkey intermediate-1/intermediate.key \
    -CAcreateserial -out end-entity/client.crt \
    -days 365 -sha256 \
    -extfile <(echo -e "basicConstraints=CA:FALSE\nkeyUsage=critical,digitalSignature\nextendedKeyUsage=clientAuth")
```

#### Code Signing Certificate

```bash
# Generate code signing key
openssl genrsa -out end-entity/codesign.key 2048

# Create CSR
openssl req -new -key end-entity/codesign.key \
    -subj "/C=US/ST=State/L=City/O=MyOrg/OU=Development/CN=MyOrg Code Signing" \
    -out end-entity/codesign.csr

# Sign with the last CA in chain
openssl x509 -req -in end-entity/codesign.csr \
    -CA intermediate-1/intermediate.crt -CAkey intermediate-1/intermediate.key \
    -CAcreateserial -out end-entity/codesign.crt \
    -days 365 -sha256 \
    -extfile <(echo -e "basicConstraints=CA:FALSE\nkeyUsage=critical,digitalSignature\nextendedKeyUsage=codeSigning")
```

### Step 4: Create Full Chain

```bash
# Concatenate certificates in order: end-entity -> intermediate -> root
cat end-entity/server.crt intermediate-1/intermediate.crt root/root-ca.crt > end-entity/fullchain.crt

# Create PKCS#12 bundle (for import into browsers/applications)
openssl pkcs12 -export -out end-entity/server.p12 \
    -inkey end-entity/server.key \
    -in end-entity/server.crt \
    -certfile intermediate-1/intermediate.crt \
    -name "server.example.com"
```

### Step 5: Verify Chain

```bash
# Verify certificate chain
openssl verify -CAfile root/root-ca.crt \
    -untrusted intermediate-1/intermediate.crt \
    end-entity/server.crt

# View certificate details
openssl x509 -in end-entity/server.crt -text -noout

# Check certificate expiration
openssl x509 -in end-entity/server.crt -noout -dates
```

## Advanced Certificate Extensions

### Key Usage Configuration

Key Usage defines the purpose of the key contained in the certificate. Configure based on certificate type:

```
┌─────────────────────┬────────────────────────────────────────────────────┐
│ Certificate Type    │ Recommended Key Usage                              │
├─────────────────────┼────────────────────────────────────────────────────┤
│ Root CA             │ keyCertSign, cRLSign                               │
│ Intermediate CA     │ keyCertSign, cRLSign                               │
│ Server (TLS)        │ digitalSignature, keyEncipherment                  │
│ Server (TLS 1.3)    │ digitalSignature, keyAgreement                     │
│ Client (mTLS)       │ digitalSignature                                   │
│ Code Signing        │ digitalSignature                                   │
│ S/MIME              │ digitalSignature, keyEncipherment, dataEncipherment│
└─────────────────────┴────────────────────────────────────────────────────┘
```

**Example - Custom Key Usage:**
```bash
# Server certificate with custom key usage
-extfile <(echo -e "basicConstraints=CA:FALSE\nkeyUsage=critical,digitalSignature,keyAgreement\nextendedKeyUsage=serverAuth")
```

### Authority Information Access (AIA)

AIA provides URLs to access CA information. Two key components:

**1. OCSP (Online Certificate Status Protocol)**
- URL for real-time certificate status checking
- Format: `OCSP;URI:http://ocsp.example.com`

**2. CA Issuers**
- URL to download the issuer's certificate
- Format: `CA Issuers;URI:http://pki.example.com/ca.crt`

**Example - AIA Configuration:**
```bash
# End-entity certificate with AIA
AIA_EXTENSION="authorityInfoAccess=OCSP;URI:http://ocsp.example.com,CA Issuers;URI:http://pki.example.com/intermediate.crt"

openssl x509 -req -in server.csr \
    -CA intermediate.crt -CAkey intermediate.key \
    -CAcreateserial -out server.crt -days 365 -sha256 \
    -extfile <(echo -e "basicConstraints=CA:FALSE\nkeyUsage=critical,digitalSignature,keyEncipherment\nextendedKeyUsage=serverAuth\nsubjectAltName=DNS:example.com\n$AIA_EXTENSION")
```

**For CA Certificates (point to next level up):**
```bash
# Intermediate CA with AIA pointing to root
CA_AIA="authorityInfoAccess=OCSP;URI:http://ocsp.example.com,CA Issuers;URI:http://pki.example.com/root.crt"
```

### CRL Distribution Points (CRLDP)

CRLDP specifies where to find the Certificate Revocation List (CRL).

**Example - CRLDP Configuration:**
```bash
# Single distribution point
CRLDP="crlDistributionPoints=URI:http://pki.example.com/root.crl"

# Multiple distribution points (redundancy)
CRLDP="crlDistributionPoints=URI:http://pki.example.com/crl/root.crl,URI:http://pki-backup.example.com/crl/root.crl"

# Full example with CRLDP
openssl x509 -req -in server.csr \
    -CA intermediate.crt -CAkey intermediate.key \
    -CAcreateserial -out server.crt -days 365 -sha256 \
    -extfile <(echo -e "basicConstraints=CA:FALSE\nkeyUsage=critical,digitalSignature,keyEncipherment\nextendedKeyUsage=serverAuth\nsubjectAltName=DNS:example.com\nauthorityInfoAccess=OCSP;URI:http://ocsp.example.com,CA Issuers;URI:http://pki.example.com/intermediate.crt\ncrlDistributionPoints=URI:http://pki.example.com/crl/intermediate.crl")
```

### Complete Extension Template

For a fully configured certificate with all extensions:

```bash
# Extension configuration file (extensions.cnf)
cat > extensions.cnf << 'EOF'
# Basic constraints
basicConstraints = CA:FALSE

# Key usage
keyUsage = critical, digitalSignature, keyEncipherment

# Extended key usage
extendedKeyUsage = serverAuth

# Subject Alternative Name
subjectAltName = DNS:example.com, DNS:www.example.com, IP:192.168.1.1

# Authority Information Access
authorityInfoAccess = OCSP;URI:http://ocsp.example.com,CA Issuers;URI:http://pki.example.com/intermediate.crt

# CRL Distribution Points
crlDistributionPoints = URI:http://pki.example.com/crl/intermediate.crl

# Subject Key Identifier (auto-generated)
subjectKeyIdentifier = hash

# Authority Key Identifier (auto-generated from issuer)
authorityKeyIdentifier = keyid,issuer
EOF

# Sign certificate with extensions file
openssl x509 -req -in server.csr \
    -CA intermediate.crt -CAkey intermediate.key \
    -CAcreateserial -out server.crt -days 365 -sha256 \
    -extfile extensions.cnf
```

### CA Certificate Extensions with AIA and CRLDP

For intermediate CA certificates:

```bash
cat > ca_extensions.cnf << 'EOF'
# CA constraints
basicConstraints = critical, CA:TRUE, pathlen:0

# Key usage for CA
keyUsage = critical, keyCertSign, cRLSign

# Subject/Authority Key Identifiers
subjectKeyIdentifier = hash
authorityKeyIdentifier = keyid:always,issuer

# AIA - point to parent CA
authorityInfoAccess = OCSP;URI:http://ocsp.example.com,CA Issuers;URI:http://pki.example.com/root.crt

# CRLDP - where to find this CA's CRL
crlDistributionPoints = URI:http://pki.example.com/crl/root.crl
EOF

# Sign intermediate CA
openssl x509 -req -in intermediate.csr \
    -CA root.crt -CAkey root.key \
    -CAcreateserial -out intermediate.crt -days 1825 -sha256 \
    -extfile ca_extensions.cnf
```

## Configuration Templates

### OpenSSL Config File for Root CA

For more advanced setups, use a config file:

```ini
[ ca ]
default_ca = CA_default

[ CA_default ]
dir               = ./root
database          = $dir/index.txt
serial            = $dir/serial
new_certs_dir     = $dir/newcerts
certificate       = $dir/root-ca.crt
private_key       = $dir/root-ca.key
default_days      = 365
default_md        = sha256
policy            = policy_loose

[ policy_loose ]
countryName             = optional
stateOrProvinceName     = optional
localityName            = optional
organizationName        = optional
organizationalUnitName  = optional
commonName              = supplied
emailAddress            = optional

[ req ]
default_bits        = 4096
distinguished_name  = req_distinguished_name
string_mask         = utf8only
default_md          = sha256
x509_extensions     = v3_ca

[ req_distinguished_name ]
countryName                     = Country Name (2 letter code)
stateOrProvinceName             = State or Province Name
localityName                    = Locality Name
0.organizationName              = Organization Name
organizationalUnitName          = Organizational Unit Name
commonName                      = Common Name

[ v3_ca ]
subjectKeyIdentifier = hash
authorityKeyIdentifier = keyid:always,issuer
basicConstraints = critical, CA:true
keyUsage = critical, digitalSignature, cRLSign, keyCertSign

[ v3_intermediate_ca ]
subjectKeyIdentifier = hash
authorityKeyIdentifier = keyid:always,issuer
basicConstraints = critical, CA:true, pathlen:0
keyUsage = critical, digitalSignature, cRLSign, keyCertSign

# === Server Certificate with AIA and CRLDP ===
[ v3_server ]
basicConstraints = CA:FALSE
keyUsage = critical, digitalSignature, keyEncipherment
extendedKeyUsage = serverAuth
subjectKeyIdentifier = hash
authorityKeyIdentifier = keyid,issuer
authorityInfoAccess = OCSP;URI:http://ocsp.example.com,CA Issuers;URI:http://pki.example.com/intermediate.crt
crlDistributionPoints = URI:http://pki.example.com/crl/intermediate.crl

# === Client Certificate with AIA and CRLDP ===
[ v3_client ]
basicConstraints = CA:FALSE
keyUsage = critical, digitalSignature
extendedKeyUsage = clientAuth
subjectKeyIdentifier = hash
authorityKeyIdentifier = keyid,issuer
authorityInfoAccess = OCSP;URI:http://ocsp.example.com,CA Issuers;URI:http://pki.example.com/intermediate.crt
crlDistributionPoints = URI:http://pki.example.com/crl/intermediate.crl

# === Code Signing Certificate ===
[ v3_codesign ]
basicConstraints = CA:FALSE
keyUsage = critical, digitalSignature
extendedKeyUsage = codeSigning
subjectKeyIdentifier = hash
authorityKeyIdentifier = keyid,issuer
authorityInfoAccess = OCSP;URI:http://ocsp.example.com,CA Issuers;URI:http://pki.example.com/intermediate.crt
crlDistributionPoints = URI:http://pki.example.com/crl/intermediate.crl
```

## Common Patterns

### Quick Single-Level Chain (Root + Server)

```bash
# All-in-one for simple testing
mkdir -p certs/{root,server}

# Root CA
openssl req -x509 -newkey rsa:4096 -keyout certs/root/ca.key -out certs/root/ca.crt \
    -days 3650 -nodes -subj "/CN=Test Root CA"

# Server cert
openssl req -newkey rsa:2048 -keyout certs/server/server.key -out certs/server/server.csr \
    -nodes -subj "/CN=localhost"

openssl x509 -req -in certs/server/server.csr -CA certs/root/ca.crt -CAkey certs/root/ca.key \
    -CAcreateserial -out certs/server/server.crt -days 365 \
    -extfile <(echo "subjectAltName=DNS:localhost,IP:127.0.0.1")

# Cleanup
rm certs/server/server.csr
```

### ECDSA Certificates (Modern, Faster)

```bash
# Use P-256 curve for better performance
openssl ecparam -genkey -name prime256v1 -out end-entity/server.key
openssl req -new -key end-entity/server.key -out end-entity/server.csr -subj "/CN=server.example.com"
```

## Troubleshooting

### "unable to write 'random state'"
Add `-rand -` flag or ignore (cosmetic issue in old OpenSSL versions)

### "certificate signature failure"
Ensure you're using the correct parent CA key for signing

### Verification fails
- Check certificate order in chain file (leaf -> intermediate -> root)
- Ensure all intermediates are included with `-untrusted` flag
- Verify system clock is correct

### SAN not appearing in certificate
Use `-extfile` with explicit subjectAltName extension

## Important Notes

- **Never share private keys** (.key files)
- **For production**: Use proper CA infrastructure (Vault, cfssl, Let's Encrypt)
- **Secure storage**: Protect root CA key with strong passphrase
- **Rotation**: Plan for certificate renewal before expiration
- **Test trust**: Import root CA into browser/client trust store for testing