#!/bin/bash
# verify-chain.sh - Verify a certificate chain
# Usage: ./verify-chain.sh <chain-dir> [cert-name]

set -e

CHAIN_DIR=${1:-./certs}
CERT_NAME=${2:-server}

echo "Verifying certificate chain in: $CHAIN_DIR"
echo ""

# Check if directory exists
if [ ! -d "$CHAIN_DIR" ]; then
    echo "Error: Directory $CHAIN_DIR does not exist"
    exit 1
fi

# Find all CA certificates
ROOT_CA="$CHAIN_DIR/root/root-ca.crt"
if [ ! -f "$ROOT_CA" ]; then
    echo "Error: Root CA not found at $ROOT_CA"
    exit 1
fi

# Find intermediate CAs
INTERMEDIATES=()
for dir in "$CHAIN_DIR"/intermediate-*; do
    if [ -d "$dir" ]; then
        cert="$dir/intermediate.crt"
        if [ -f "$cert" ]; then
            INTERMEDIATES+=("$cert")
        fi
    fi
done

# Find end-entity certificate
END_CERT="$CHAIN_DIR/end-entity/${CERT_NAME}.crt"
if [ ! -f "$END_CERT" ]; then
    echo "Error: End-entity certificate not found at $END_CERT"
    exit 1
fi

echo "=== Chain Structure ==="
echo "Root CA: $ROOT_CA"
for int in "${INTERMEDIATES[@]}"; do
    echo "Intermediate: $int"
done
echo "End-entity: $END_CERT"
echo ""

# Build verification command
VERIFY_CMD="openssl verify -CAfile $ROOT_CA"
for int in "${INTERMEDIATES[@]}"; do
    VERIFY_CMD="$VERIFY_CMD -untrusted $int"
done
VERIFY_CMD="$VERIFY_CMD $END_CERT"

echo "=== Verification Result ==="
if $VERIFY_CMD 2>&1; then
    echo ""
    echo "✓ Certificate chain is valid!"
else
    echo ""
    echo "✗ Certificate chain verification failed!"
    exit 1
fi

echo ""
echo "=== Certificate Details ==="
echo ""
echo "--- Root CA ---"
openssl x509 -in "$ROOT_CA" -noout -subject -issuer -dates 2>/dev/null

for int in "${INTERMEDIATES[@]}"; do
    echo ""
    echo "--- Intermediate CA ---"
    openssl x509 -in "$int" -noout -subject -issuer -dates 2>/dev/null
done

echo ""
echo "--- End-entity Certificate ---"
openssl x509 -in "$END_CERT" -noout -subject -issuer -dates -ext subjectAltName 2>/dev/null

echo ""
echo "=== Certificate Fingerprint ==="
openssl x509 -in "$END_CERT" -noout -fingerprint -sha256 2>/dev/null | sed 's/sha256 Fingerprint=/SHA256: /'