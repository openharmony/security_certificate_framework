#!/bin/bash
# issue-cert.sh - Issue a certificate with configurable extensions
# Usage: ./issue-cert.sh [options]
#
# Options:
#   -t, --type         Certificate type: server, client, codesign (default: server)
#   -c, --ca-cert      CA certificate path (required)
#   -k, --ca-key       CA private key path (required)
#   -s, --subject      Subject DN (e.g., "/CN=example.com/O=MyOrg")
#   -n, --san          Subject Alternative Names (comma-separated)
#   -d, --days         Validity in days (default: 365)
#   --key-usage        Custom key usage (comma-separated)
#   --ext-key-usage    Extended key usage (comma-separated)
#   --ocsp             OCSP responder URL
#   --issuer-url       CA Issuers URL
#   --crldp            CRL distribution point URL
#   -o, --output       Output directory (default: ./certs)
#   -h, --help         Show this help

set -e

# Default values
CERT_TYPE="server"
DAYS=365
OUTPUT_DIR="./certs"
KEY_SIZE=2048

# Parse arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        -t|--type)
            CERT_TYPE="$2"
            shift 2
            ;;
        -c|--ca-cert)
            CA_CERT="$2"
            shift 2
            ;;
        -k|--ca-key)
            CA_KEY="$2"
            shift 2
            ;;
        -s|--subject)
            SUBJECT="$2"
            shift 2
            ;;
        -n|--san)
            SAN="$2"
            shift 2
            ;;
        -d|--days)
            DAYS="$2"
            shift 2
            ;;
        --key-usage)
            KEY_USAGE="$2"
            shift 2
            ;;
        --ext-key-usage)
            EXT_KEY_USAGE="$2"
            shift 2
            ;;
        --ocsp)
            OCSP_URL="$2"
            shift 2
            ;;
        --issuer-url)
            ISSUER_URL="$2"
            shift 2
            ;;
        --crldp)
            CRLDP_URL="$2"
            shift 2
            ;;
        -o|--output)
            OUTPUT_DIR="$2"
            shift 2
            ;;
        -h|--help)
            sed -n '/^# Usage:/,/^$/p' "$0" | sed 's/^# //'
            exit 0
            ;;
        *)
            echo "Unknown option: $1"
            exit 1
            ;;
    esac
done

# Validate required parameters
if [[ -z "$CA_CERT" || -z "$CA_KEY" ]]; then
    echo "Error: CA certificate and key are required"
    echo "Use -c/--ca-cert and -k/--ca-key options"
    exit 1
fi

if [[ ! -f "$CA_CERT" ]]; then
    echo "Error: CA certificate not found: $CA_CERT"
    exit 1
fi

if [[ ! -f "$CA_KEY" ]]; then
    echo "Error: CA key not found: $CA_KEY"
    exit 1
fi

# Set defaults based on certificate type
case "$CERT_TYPE" in
    server)
        KEY_USAGE="${KEY_USAGE:-digitalSignature,keyEncipherment}"
        EXT_KEY_USAGE="${EXT_KEY_USAGE:-serverAuth}"
        CERT_NAME="${CERT_NAME:-server}"
        ;;
    client)
        KEY_USAGE="${KEY_USAGE:-digitalSignature}"
        EXT_KEY_USAGE="${EXT_KEY_USAGE:-clientAuth}"
        CERT_NAME="${CERT_NAME:-client}"
        ;;
    codesign)
        KEY_USAGE="${KEY_USAGE:-digitalSignature}"
        EXT_KEY_USAGE="${EXT_KEY_USAGE:-codeSigning}"
        CERT_NAME="${CERT_NAME:-codesign}"
        ;;
    *)
        echo "Error: Unknown certificate type: $CERT_TYPE"
        echo "Valid types: server, client, codesign"
        exit 1
        ;;
esac

# Create output directory
mkdir -p "$OUTPUT_DIR"

# Generate key and CSR
echo "Generating private key..."
openssl genrsa -out "$OUTPUT_DIR/${CERT_NAME}.key" $KEY_SIZE 2>/dev/null

echo "Creating CSR..."
if [[ -n "$SUBJECT" ]]; then
    openssl req -new -key "$OUTPUT_DIR/${CERT_NAME}.key" \
        -subj "$SUBJECT" \
        -out "$OUTPUT_DIR/${CERT_NAME}.csr" 2>/dev/null
else
    openssl req -new -key "$OUTPUT_DIR/${CERT_NAME}.key" \
        -out "$OUTPUT_DIR/${CERT_NAME}.csr" 2>/dev/null
fi

# Build extension config
EXT_FILE=$(mktemp)

cat > "$EXT_FILE" << EOF
basicConstraints = CA:FALSE
keyUsage = critical, $KEY_USAGE
extendedKeyUsage = $EXT_KEY_USAGE
subjectKeyIdentifier = hash
authorityKeyIdentifier = keyid,issuer
EOF

# Add SAN if specified
if [[ -n "$SAN" ]]; then
    SAN_ENTRIES=""
    IFS=',' read -ra SAN_ARRAY <<< "$SAN"
    for entry in "${SAN_ARRAY[@]}"; do
        entry=$(echo "$entry" | xargs)  # trim whitespace
        if [[ "$entry" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
            SAN_ENTRIES="${SAN_ENTRIES},IP:${entry}"
        else
            SAN_ENTRIES="${SAN_ENTRIES},DNS:${entry}"
        fi
    done
    SAN_ENTRIES="${SAN_ENTRIES#,}"  # remove leading comma
    echo "subjectAltName = $SAN_ENTRIES" >> "$EXT_FILE"
fi

# Add AIA if specified
AIA_ENTRIES=""
if [[ -n "$OCSP_URL" ]]; then
    AIA_ENTRIES="OCSP;URI:${OCSP_URL}"
fi
if [[ -n "$ISSUER_URL" ]]; then
    if [[ -n "$AIA_ENTRIES" ]]; then
        AIA_ENTRIES="${AIA_ENTRIES},CA Issuers;URI:${ISSUER_URL}"
    else
        AIA_ENTRIES="CA Issuers;URI:${ISSUER_URL}"
    fi
fi
if [[ -n "$AIA_ENTRIES" ]]; then
    echo "authorityInfoAccess = $AIA_ENTRIES" >> "$EXT_FILE"
fi

# Add CRLDP if specified
if [[ -n "$CRLDP_URL" ]]; then
    echo "crlDistributionPoints = URI:${CRLDP_URL}" >> "$EXT_FILE"
fi

# Sign the certificate
echo "Signing certificate..."
openssl x509 -req -in "$OUTPUT_DIR/${CERT_NAME}.csr" \
    -CA "$CA_CERT" -CAkey "$CA_KEY" \
    -CAcreateserial -out "$OUTPUT_DIR/${CERT_NAME}.crt" \
    -days "$DAYS" -sha256 \
    -extfile "$EXT_FILE" 2>/dev/null

# Cleanup
rm "$OUTPUT_DIR/${CERT_NAME}.csr" "$EXT_FILE"

echo ""
echo "=== Certificate issued successfully! ==="
echo ""
echo "Output files:"
echo "  Certificate: $OUTPUT_DIR/${CERT_NAME}.crt"
echo "  Private key: $OUTPUT_DIR/${CERT_NAME}.key"
echo ""
echo "Extensions applied:"
echo "  Key Usage: $KEY_USAGE"
echo "  Extended Key Usage: $EXT_KEY_USAGE"
[[ -n "$SAN" ]] && echo "  SAN: $SAN"
[[ -n "$OCSP_URL" ]] && echo "  OCSP: $OCSP_URL"
[[ -n "$ISSUER_URL" ]] && echo "  CA Issuers: $ISSUER_URL"
[[ -n "$CRLDP_URL" ]] && echo "  CRLDP: $CRLDP_URL"
echo ""
echo "To verify: openssl x509 -in $OUTPUT_DIR/${CERT_NAME}.crt -text -noout"