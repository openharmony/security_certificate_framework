#!/bin/bash
# create-chain.sh - Create a certificate chain with configurable depth
# Usage: ./create-chain.sh <depth> <output-dir> <subject-prefix>

set -e

DEPTH=${1:-2}
OUTPUT_DIR=${2:-./certs}
SUBJECT_PREFIX=${3:-"/C=US/ST=State/L=City/O=MyOrg"}

if [ "$DEPTH" -lt 2 ]; then
    echo "Error: Depth must be at least 2 (root + end-entity)"
    exit 1
fi

echo "Creating certificate chain with depth: $DEPTH"

# Create directory structure
mkdir -p "$OUTPUT_DIR"/root
for i in $(seq 1 $((DEPTH - 2))); do
    mkdir -p "$OUTPUT_DIR"/intermediate-$i
done
mkdir -p "$OUTPUT_DIR"/end-entity

# Step 1: Create Root CA
echo "[1/4] Creating Root CA..."
openssl genrsa -out "$OUTPUT_DIR"/root/root-ca.key 4096 2>/dev/null
openssl req -x509 -new -nodes -key "$OUTPUT_DIR"/root/root-ca.key \
    -sha256 -days 3650 \
    -subj "${SUBJECT_PREFIX}/OU=Root CA/CN=Root CA" \
    -out "$OUTPUT_DIR"/root/root-ca.crt 2>/dev/null
echo "01" > "$OUTPUT_DIR"/root/root-ca.srl

# Step 2: Create Intermediate CAs
PARENT_DIR="root"
PARENT_NAME="root-ca"

for i in $(seq 1 $((DEPTH - 2))); do
    echo "[2/4] Creating Intermediate CA $i..."
    CURRENT_DIR="intermediate-$i"

    openssl genrsa -out "$OUTPUT_DIR"/$CURRENT_DIR/intermediate.key 4096 2>/dev/null
    openssl req -new -key "$OUTPUT_DIR"/$CURRENT_DIR/intermediate.key \
        -subj "${SUBJECT_PREFIX}/OU=Intermediate CA $i/CN=Intermediate CA $i" \
        -out "$OUTPUT_DIR"/$CURRENT_DIR/intermediate.csr 2>/dev/null

    openssl x509 -req -in "$OUTPUT_DIR"/$CURRENT_DIR/intermediate.csr \
        -CA "$OUTPUT_DIR"/$PARENT_DIR/$PARENT_NAME.crt \
        -CAkey "$OUTPUT_DIR"/$PARENT_DIR/$PARENT_NAME.key \
        -CAcreateserial -out "$OUTPUT_DIR"/$CURRENT_DIR/intermediate.crt \
        -days 1825 -sha256 2>/dev/null \
        -extfile <(echo -e "basicConstraints=critical,CA:TRUE,pathlen:$((DEPTH - 2 - i))\nkeyUsage=critical,keyCertSign,cRLSign")

    echo "01" > "$OUTPUT_DIR"/$CURRENT_DIR/intermediate.srl
    rm "$OUTPUT_DIR"/$CURRENT_DIR/intermediate.csr

    PARENT_DIR=$CURRENT_DIR
    PARENT_NAME="intermediate"
done

# Step 3: Create end-entity certificate (server)
echo "[3/4] Creating end-entity certificate..."
openssl genrsa -out "$OUTPUT_DIR"/end-entity/server.key 2048 2>/dev/null
openssl req -new -key "$OUTPUT_DIR"/end-entity/server.key \
    -subj "${SUBJECT_PREFIX}/OU=Server/CN=localhost" \
    -out "$OUTPUT_DIR"/end-entity/server.csr 2>/dev/null

openssl x509 -req -in "$OUTPUT_DIR"/end-entity/server.csr \
    -CA "$OUTPUT_DIR"/$PARENT_DIR/$PARENT_NAME.crt \
    -CAkey "$OUTPUT_DIR"/$PARENT_DIR/$PARENT_NAME.key \
    -CAcreateserial -out "$OUTPUT_DIR"/end-entity/server.crt \
    -days 365 -sha256 2>/dev/null \
    -extfile <(echo -e "basicConstraints=CA:FALSE\nkeyUsage=critical,digitalSignature,keyEncipherment\nextendedKeyUsage=serverAuth\nsubjectAltName=DNS:localhost,DNS:*.local,IP:127.0.0.1")

rm "$OUTPUT_DIR"/end-entity/server.csr

# Step 4: Create full chain
echo "[4/4] Creating full chain..."
CHAIN_FILE="$OUTPUT_DIR"/end-entity/fullchain.crt
cat "$OUTPUT_DIR"/end-entity/server.crt > "$CHAIN_FILE"

# Add intermediates in reverse order (closest to leaf first)
for i in $(seq $((DEPTH - 2)) -1 1); do
    cat "$OUTPUT_DIR"/intermediate-$i/intermediate.crt >> "$CHAIN_FILE"
done

cat "$OUTPUT_DIR"/root/root-ca.crt >> "$CHAIN_FILE"

echo ""
echo "=== Certificate chain created successfully! ==="
echo ""
echo "Files created in $OUTPUT_DIR/:"
echo "  Root CA:     root/root-ca.crt, root/root-ca.key"
if [ "$DEPTH" -gt 2 ]; then
    echo "  Intermediate: intermediate-{1..$((DEPTH-2))}/"
fi
echo "  End-entity:  end-entity/server.crt, end-entity/server.key"
echo "  Full chain:  end-entity/fullchain.crt"
echo ""
echo "To verify:"
echo "  openssl verify -CAfile $OUTPUT_DIR/root/root-ca.crt \\"
if [ "$DEPTH" -gt 2 ]; then
    for i in $(seq 1 $((DEPTH - 2))); do
        echo "    -untrusted $OUTPUT_DIR/intermediate-$i/intermediate.crt \\"
    done
fi
echo "    $OUTPUT_DIR/end-entity/server.crt"