# OpenSSL Quick Reference

## Key Generation

| Type | Command |
|------|---------|
| RSA 4096 | `openssl genrsa -out key.pem 4096` |
| RSA 2048 | `openssl genrsa -out key.pem 2048` |
| ECDSA P-256 | `openssl ecparam -genkey -name prime256v1 -out key.pem` |
| ECDSA P-384 | `openssl ecparam -genkey -name secp384r1 -out key.pem` |

## Certificate Extensions

### CA Certificate
```
basicConstraints = critical, CA:TRUE
keyUsage = critical, keyCertSign, cRLSign
```

### Intermediate CA
```
basicConstraints = critical, CA:TRUE, pathlen:0
keyUsage = critical, keyCertSign, cRLSign
```

### Server Certificate
```
basicConstraints = CA:FALSE
keyUsage = critical, digitalSignature, keyEncipherment
extendedKeyUsage = serverAuth
subjectAltName = DNS:example.com, DNS:www.example.com, IP:192.168.1.1
```

### Client Certificate
```
basicConstraints = CA:FALSE
keyUsage = critical, digitalSignature
extendedKeyUsage = clientAuth
```

### Code Signing Certificate
```
basicConstraints = CA:FALSE
keyUsage = critical, digitalSignature
extendedKeyUsage = codeSigning
```

## Common Commands

```bash
# Generate self-signed certificate
openssl req -x509 -newkey rsa:4096 -keyout key.pem -out cert.pem -days 365 -nodes

# Create CSR
openssl req -new -key key.pem -out request.csr -subj "/CN=example.com"

# Sign CSR with CA
openssl x509 -req -in request.csr -CA ca.crt -CAkey ca.key -CAcreateserial -out cert.pem -days 365

# View certificate
openssl x509 -in cert.pem -text -noout

# View CSR
openssl req -in request.csr -text -noout

# Check key modulus matches certificate
openssl x509 -noout -modulus -in cert.pem | openssl md5
openssl rsa -noout -modulus -in key.pem | openssl md5

# Convert PEM to PKCS#12
openssl pkcs12 -export -out cert.p12 -inkey key.pem -in cert.pem -certfile chain.pem

# Convert PKCS#12 to PEM
openssl pkcs12 -in cert.p12 -out cert.pem -nodes

# Test TLS connection
openssl s_client -connect server:443 -CAfile ca.crt

# Verify certificate chain
openssl verify -CAfile root.crt -untrusted intermediate.crt cert.pem
```

## Subject Alternative Name (SAN) Examples

```
# Single domain
subjectAltName = DNS:example.com

# Multiple domains
subjectAltName = DNS:example.com, DNS:www.example.com, DNS:api.example.com

# With IP addresses
subjectAltName = DNS:example.com, IP:192.168.1.1, IP:127.0.0.1

# Wildcard
subjectAltName = DNS:*.example.com

# Email
subjectAltName = email:admin@example.com
```

## Validity Periods

| Certificate Type | Recommended Validity |
|-----------------|---------------------|
| Root CA | 10-20 years |
| Intermediate CA | 5-10 years |
| Server Certificate | 1 year (max 398 days for public) |
| Client Certificate | 1-3 years |
| Code Signing | 1-3 years |

## Key Usage Reference

| Flag | Description |
|------|-------------|
| digitalSignature | Signing data (not certificates) |
| keyEncipherment | Encrypting symmetric keys |
| keyCertSign | Signing certificates (CA only) |
| cRLSign | Signing CRLs (CA only) |
| dataEncipherment | Encrypting data directly |
| keyAgreement | Key derivation (e.g., Diffie-Hellman) |

## Authority Information Access (AIA)

AIA provides URLs for certificate validation resources.

### Syntax
```
authorityInfoAccess = <method>;<URI-type>:<URI>, ...
```

### OCSP Responder
```
# HTTP endpoint for real-time certificate status
authorityInfoAccess = OCSP;URI:http://ocsp.example.com
```

### CA Issuers (Certificate Chain)
```
# URL to download the issuer's certificate
authorityInfoAccess = CA Issuers;URI:http://pki.example.com/ca.crt
```

### Combined AIA
```
# Both OCSP and CA Issuers
authorityInfoAccess = OCSP;URI:http://ocsp.example.com,CA Issuers;URI:http://pki.example.com/intermediate.crt
```

## CRL Distribution Points (CRLDP)

CRLDP specifies where to find Certificate Revocation Lists.

### Syntax
```
crlDistributionPoints = URI:<url>
```

### Examples
```
# Single distribution point
crlDistributionPoints = URI:http://pki.example.com/crl/root.crl

# Multiple distribution points (redundancy)
crlDistributionPoints = URI:http://pki.example.com/crl/intermediate.crl,URI:http://backup.example.com/crl/intermediate.crl

# LDAP distribution point
crlDistributionPoints = URI:ldap://ldap.example.com/CN=root-ca,CN=CDP,CN=Public%20Key%20Services,CN=Services,CN=Configuration,DC=example,DC=com?certificateRevocationList?base?objectClass=cRLDistributionPoint
```

## Complete Certificate with All Extensions

```bash
# Full extension configuration
openssl x509 -req -in server.csr -CA ca.crt -CAkey ca.key -CAcreateserial \
    -out server.crt -days 365 -sha256 \
    -extfile <(cat << 'EOF'
basicConstraints = CA:FALSE
keyUsage = critical, digitalSignature, keyEncipherment
extendedKeyUsage = serverAuth
subjectKeyIdentifier = hash
authorityKeyIdentifier = keyid,issuer
subjectAltName = DNS:example.com, DNS:www.example.com, IP:192.168.1.1
authorityInfoAccess = OCSP;URI:http://ocsp.example.com,CA Issuers;URI:http://pki.example.com/intermediate.crt
crlDistributionPoints = URI:http://pki.example.com/crl/intermediate.crl
EOF
)
```

## Extended Key Usage Reference

| OID | Name | Use Case |
|-----|------|----------|
| 1.3.6.1.5.5.7.3.1 | serverAuth | TLS/SSL server |
| 1.3.6.1.5.5.7.3.2 | clientAuth | TLS/SSL client (mTLS) |
| 1.3.6.1.5.5.7.3.3 | codeSigning | Code signing |
| 1.3.6.1.5.5.7.3.4 | emailProtection | S/MIME |
| 1.3.6.1.5.5.7.3.8 | timeStamping | Time stamping |
| 1.3.6.1.5.5.7.3.9 | OCSPSigning | OCSP responder |